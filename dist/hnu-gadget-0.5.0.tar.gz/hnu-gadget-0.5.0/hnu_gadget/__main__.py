from . import application


def main():
	application.run()
