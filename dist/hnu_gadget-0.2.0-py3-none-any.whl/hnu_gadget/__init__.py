from . import application

__version__ = '0.2.0'


def main():
	application.run()
